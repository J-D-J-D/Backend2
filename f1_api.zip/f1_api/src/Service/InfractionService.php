<?php
namespace App\Service;

use App\Entity\Infraction;
use Doctrine\ORM\EntityManagerInterface;
use App\Entity\Driver;

class InfractionService
{
    public function onInfractionAdded(Infraction $infraction, EntityManagerInterface $em): void
    {
        $driver = $infraction->getDriver();
        if ($driver && $infraction->getType() === 'penalty' && $infraction->getPoints()) {
            $driver->setLicensePoints($driver->getLicensePoints() - $infraction->getPoints());

            if ($driver->getLicensePoints() < 1) {
                $driver->setStatus(Driver::STATUS_SUSPENDED);
            }

            $em->persist($driver);
            $em->flush();
        }
    }
}
<?php
namespace App\Controller;

use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Doctrine\ORM\EntityManagerInterface;
use App\Entity\Infraction;
use App\Entity\Driver;
use App\Entity\Team;
use App\Service\InfractionService;

class InfractionController extends AbstractController
{
    private InfractionService $infractionService;

    public function __construct(InfractionService $infractionService)
    {
        $this->infractionService = $infractionService;
    }

    public function create(Request $request, EntityManagerInterface $em): JsonResponse
    {
        $data = json_decode($request->getContent(), true);
        $type = $data['type'] ?? null;
        $raceName = $data['raceName'] ?? null;
        $desc = $data['description'] ?? null;

        if (!$type || !$raceName || !$desc) {
            return new JsonResponse(['error' => 'type, raceName and description required'], 400);
        }

        $infraction = new Infraction();
        $infraction->setType($type);
        $infraction->setRaceName($raceName);
        $infraction->setDescription($desc);
        $infraction->setHappenedAt(isset($data['happenedAt']) ? new \DateTime($data['happenedAt']) : new \DateTime());

        if (isset($data['driverId'])) {
            $driver = $em->getRepository(Driver::class)->find($data['driverId']);
            if (!$driver) return new JsonResponse(['error' => 'Driver not found'], 404);
            $infraction->setDriver($driver);
        }

        if (isset($data['teamId'])) {
            $team = $em->getRepository(Team::class)->find($data['teamId']);
            if (!$team) return new JsonResponse(['error' => 'Team not found'], 404);
            $infraction->setTeam($team);
        }

        if ($type === 'penalty') {
            $infraction->setPoints($data['points'] ?? null);
        } elseif ($type === 'fine') {
            $infraction->setAmount($data['amount'] ?? null);
        }

        $em->persist($infraction);
        $em->flush();

        $this->infractionService->onInfractionAdded($infraction, $em);

        return new JsonResponse(['status' => 'created', 'id' => $infraction->getId()], 201);
    }

    public function list(Request $request, EntityManagerInterface $em): JsonResponse
    {
        $qb = $em->createQueryBuilder()
        ->select('i', 'd', 't')
        ->from(Infraction::class, 'i')
        ->leftJoin('i.driver', 'd')
        ->leftJoin('i.team', 't')
        ->orderBy('i.happenedAt', 'DESC');

        if ($teamId = $request->query->get('team')) {
            $qb->andWhere('t.id = :team')->setParameter('team', $teamId);
        }
        if ($driverId = $request->query->get('driver')) {
            $qb->andWhere('d.id = :driver')->setParameter('driver', $driverId);
        }
        if ($date = $request->query->get('date')) {
            $start = new \DateTime($date . ' 00:00:00');
            $end = new \DateTime($date . ' 23:59:59');
            $qb->andWhere('i.happenedAt BETWEEN :start AND :end')
            ->setParameter('start', $start)
            ->setParameter('end', $end);
        }

        $infractions = $qb->getQuery()->getResult();

        $data = [];
        foreach ($infractions as $i) {
        $data[] = [
        'id' => $i->getId(),
        'type' => $i->getType(),
        'points' => $i->getPoints(),
        'amount' => $i->getAmount(),
        'raceName' => $i->getRaceName(),
        'description' => $i->getDescription(),
        'happenedAt' => $i->getHappenedAt()->format('Y-m-d H:i:s'),
        ];
        }

        return new JsonResponse($data);
    }
}
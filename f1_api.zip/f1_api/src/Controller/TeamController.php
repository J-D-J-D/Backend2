<?php
namespace App\Controller;


use Symfony\Bundle\FrameworkBundle\Controller\AbstractController;
use Symfony\Component\HttpFoundation\Request;
use Symfony\Component\HttpFoundation\JsonResponse;
use Doctrine\ORM\EntityManagerInterface;
use App\Entity\Team;
use App\Entity\Driver;

class TeamController extends AbstractController
{
    public function modifyDrivers(int $id, Request $request, EntityManagerInterface $em): JsonResponse
    {
        $team = $em->getRepository(Team::class)->find($id);
        if (!$team) {
            return new JsonResponse(['error' => 'Team not found'], 404);
        }

        $data = json_decode($request->getContent(), true);
        $driverIds = $data['driverIds'] ?? [];

        if (!is_array($driverIds)) {
            return new JsonResponse(['error' => 'driverIds must be an array'], 400);
        }

        foreach ($team->getDrivers() as $driver) {
            if (!in_array($driver->getId(), $driverIds, true)) {
                $driver->setTeam(null);
                $em->persist($driver);
            }
        }

        foreach ($driverIds as $driverId) {
            $driver = $em->getRepository(Driver::class)->find($driverId);
            if ($driver) {
                $driver->setTeam($team);
                $em->persist($driver);
            }
        }

        $em->flush();
        return new JsonResponse(['status' => 'ok']);
    }
}
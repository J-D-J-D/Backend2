<?php
namespace App\Entity;


use Doctrine\ORM\Mapping as ORM;
use Doctrine\Common\Collections\ArrayCollection;
use Doctrine\Common\Collections\Collection;


#[ORM\Entity]
class Team
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\Column(type: 'string', length: 150, unique: true)]
    private string $name;

    #[ORM\OneToMany(mappedBy: 'team', targetEntity: Driver::class, cascade: ['persist'])]
    private Collection $drivers;

    #[ORM\OneToOne(inversedBy: 'team', targetEntity: Engine::class, cascade: ['persist'])]
    #[ORM\JoinColumn(nullable: false)]
    private Engine $engine;

    public function __construct()
    {
        $this->drivers = new ArrayCollection();
    }

    public function getId(): ?int { return $this->id; }
    public function getName(): string { return $this->name; }
    public function setName(string $n): self { $this->name = $n; return $this; }

    public function getEngine(): Engine { return $this->engine; }
    public function setEngine(Engine $e): self { $this->engine = $e; return $this; }

    public function getDrivers(): Collection { return $this->drivers; }
    public function addDriver(Driver $d): self
    {
        if (!$this->drivers->contains($d)) {
            $this->drivers->add($d);
            $d->setTeam($this);
            }
        return $this;
    }
    public function removeDriver(Driver $d): self
    {
        if ($this->drivers->contains($d)) {
            $this->drivers->removeElement($d);
            if ($d->getTeam() === $this) {
                $d->setTeam(null);
                }
            }
        return $this;
    }
}
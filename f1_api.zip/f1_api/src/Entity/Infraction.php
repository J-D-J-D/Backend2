<?php
namespace App\Entity;


use Doctrine\ORM\Mapping as ORM;


#[ORM\Entity]
class Infraction
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\Column(type: 'string', length: 20)]
    private string $type;

    #[ORM\Column(type: 'integer', nullable: true)]
    private ?int $points = null;

    #[ORM\Column(type: 'decimal', precision: 10, scale: 2, nullable: true)]
    private ?string $amount = null;

    #[ORM\Column(type: 'string', length: 200)]
    private string $raceName;

    #[ORM\Column(type: 'text')]
    private string $description;

    #[ORM\Column(type: 'datetime')]
    private \DateTimeInterface $happenedAt;

    #[ORM\ManyToOne(targetEntity: Driver::class)]
    private ?Driver $driver = null;

    #[ORM\ManyToOne(targetEntity: Team::class)]
    private ?Team $team = null;

    #[ORM\Column(type: 'datetime')]
    private \DateTimeInterface $createdAt;

    public function __construct()
    {
        $this->createdAt = new \DateTimeImmutable();
    }

    public function getId(): ?int { return $this->id; }
    public function getType(): string { return $this->type; }
    public function setType(string $t): self { $this->type = $t; return $this; }

    public function getPoints(): ?int { return $this->points; }
    public function setPoints(?int $p): self { $this->points = $p; return $this; }

    public function getAmount(): ?string { return $this->amount; }
    public function setAmount(?string $a): self { $this->amount = $a; return $this; }

    public function getRaceName(): string { return $this->raceName; }
    public function setRaceName(string $r): self { $this->raceName = $r; return $this; }

    public function getDescription(): string { return $this->description; }
    public function setDescription(string $d): self { $this->description = $d; return $this; }

    public function getHappenedAt(): \DateTimeInterface { return $this->happenedAt; }
    public function setHappenedAt(\DateTimeInterface $dt): self { $this->happenedAt = $dt; return $this; }

    public function getDriver(): ?Driver { return $this->driver; }
    public function setDriver(?Driver $d): self { $this->driver = $d; return $this; }

    public function getTeam(): ?Team { return $this->team; }
    public function setTeam(?Team $t): self { $this->team = $t; return $this; }

    public function getCreatedAt(): \DateTimeInterface { return $this->createdAt; }
}
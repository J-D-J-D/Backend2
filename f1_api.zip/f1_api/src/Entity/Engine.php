<?php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
class Engine
{
    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\Column(type: 'string', length: 100)]
    private string $brand;

    #[ORM\OneToOne(mappedBy: 'engine', targetEntity: Team::class)]
    private ?Team $team = null;

    public function getId(): ?int { return $this->id; }
    public function getBrand(): string { return $this->brand; }
    public function setBrand(string $b): self { $this->brand = $b; return $this; }
}
<?php
namespace App\Entity;

use Doctrine\ORM\Mapping as ORM;

#[ORM\Entity]
class Driver
{
    public const STATUS_ACTIVE = 'ACTIVE';
    public const STATUS_SUSPENDED = 'SUSPENDED';

    #[ORM\Id]
    #[ORM\GeneratedValue]
    #[ORM\Column(type: 'integer')]
    private ?int $id = null;

    #[ORM\Column(type: 'string', length: 100)]
    private string $firstName;

    #[ORM\Column(type: 'string', length: 100)]
    private string $lastName;

    #[ORM\Column(type: 'string', length: 50)]
    private string $roleType;

    #[ORM\Column(type: 'integer')]
    private int $licensePoints = 12;

    #[ORM\Column(type: 'date')]
    private \DateTimeInterface $startF1Date;

    #[ORM\Column(type: 'string', length: 20)]
    private string $status = self::STATUS_ACTIVE;

    #[ORM\ManyToOne(targetEntity: Team::class, inversedBy: 'drivers')]
    private ?Team $team = null;

    public function getId(): ?int { return $this->id; }
    public function getFirstName(): string { return $this->firstName; }
    public function setFirstName(string $f): self { $this->firstName = $f; return $this; }
    public function getLastName(): string { return $this->lastName; }
    public function setLastName(string $l): self { $this->lastName = $l; return $this; }

    public function getRoleType(): string { return $this->roleType; }
    public function setRoleType(string $r): self { $this->roleType = $r; return $this; }

    public function getLicensePoints(): int { return $this->licensePoints; }
    public function setLicensePoints(int $p): self { $this->licensePoints = $p; return $this; }

    public function getStartF1Date(): \DateTimeInterface { return $this->startF1Date; }
    public function setStartF1Date(\DateTimeInterface $d): self { $this->startF1Date = $d; return $this; }

    public function getStatus(): string { return $this->status; }
    public function setStatus(string $s): self { $this->status = $s; return $this; }

    public function getTeam(): ?Team { return $this->team; }
    public function setTeam(?Team $t): self { $this->team = $t; return $this; }
}
<?php
namespace App\DataFixtures;

use Doctrine\Bundle\FixturesBundle\Fixture;
use Doctrine\Persistence\ObjectManager;
use App\Entity\Team;
use App\Entity\Engine;
use App\Entity\Driver;
use App\Entity\User;
use Symfony\Component\PasswordHasher\Hasher\UserPasswordHasherInterface;

class AppFixtures extends Fixture
{
    private UserPasswordHasherInterface $hasher;

    public function __construct(UserPasswordHasherInterface $hasher)
    {
        $this->hasher = $hasher;
    }

    public function load(ObjectManager $manager): void
    {
        $teamsData = [
        ['name' => 'Scuderia Alpha', 'engine' => 'Ferrari'],
        ['name' => 'Team Velocity', 'engine' => 'Mercedes'],
        ['name' => 'Red Falcon Racing', 'engine' => 'Honda'],
        ];

        foreach ($teamsData as $i => $tdata) {
            $engine = new Engine();
            $engine->setBrand($tdata['engine']);

            $team = new Team();
            $team->setName($tdata['name']);
            $team->setEngine($engine);

            $manager->persist($engine);
            $manager->persist($team);

            for ($p = 1; $p <= 3; $p++) {
                $driver = new Driver();
                $driver->setFirstName('Prenom' . $i . $p);
                $driver->setLastName('Nom' . $i . $p);
                $driver->setRoleType($p === 3 ? 'RESERVE' : 'TITULAIRE');
                $driver->setLicensePoints(12);
                $driver->setStartF1Date(new \DateTime('201' . $p . '-03-01'));
                $driver->setTeam($team);
                $manager->persist($driver);
            }
        }

        $admin = new User();
        $admin->setUsername('admin');
        $admin->setRoles(['ROLE_ADMIN']);
        $admin->setPassword($this->hasher->hashPassword($admin, 'password'));
        $manager->persist($admin);

        $manager->flush();
    }
}